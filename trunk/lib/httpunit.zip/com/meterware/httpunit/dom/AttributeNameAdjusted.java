package com.meterware.httpunit.dom;
/********************************************************************************************************************
 * $Id: AttributeNameAdjusted.java 908 2008-04-05 08:24:51Z wolfgang_fahl $
 *
 * Copyright (c) 2005, Russell Gold
 *
 *******************************************************************************************************************/

/**
 * @author <a href="mailto:russgold@gmail.com">Russell Gold</a>
 */
public interface AttributeNameAdjusted {

    String getJavaAttributeName( String attributeName );
}
